<?php if (isset($error_msg['headline'])) : $this->out( $error_msg['headline'] ); endif; ?>
<?php if (isset($error_msg['message'])) : $this->out( $error_msg['message'] ); endif; ?>