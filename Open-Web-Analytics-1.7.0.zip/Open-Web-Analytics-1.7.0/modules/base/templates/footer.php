<div class="owa_footer" style="text-align:center">
    <span class="inline_h4"><a href="http://www.openwebanalytics.com">Web Analytics</a> powered by <a href="http://www.openwebanalytics.com">Open Web Analytics</a></span>
</div>